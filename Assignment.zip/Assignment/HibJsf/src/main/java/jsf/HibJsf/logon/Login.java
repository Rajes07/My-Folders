package jsf.HibJsf.logon;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;



@ManagedBean(name="login")
@RequestScoped
public class Login implements Serializable {

	String username;
	String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	Connection connection;
	PreparedStatement pst;

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "india@123");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
	

	public String Validate() throws SQLException {
		connection = getConnection();
		String Sql="SELECT count(*) as cnt FROM userLogin WHERE Username=? AND Password=?";
		pst = connection.prepareStatement(Sql);
		pst.setString(1, username);
		pst.setString(2, password);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int cnt = rs.getInt("cnt");
		if(cnt==1) {
		return "MainTab.xhtml?faces-redirect=true";
		}
		else {
		return "Invalid Credentials...";
		}
	}
	
}
