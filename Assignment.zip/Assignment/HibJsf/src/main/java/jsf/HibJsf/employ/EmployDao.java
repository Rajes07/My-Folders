package jsf.HibJsf.employ;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



@ManagedBean(name="employDao")
public class EmployDao {

	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	SessionFactory sf;
	
	public Employ[] showEmploy() {
		sf = SessionHelper1.getConnection();
		Session s = sf.openSession();
		Query q = s.createQuery("from Employ");
		List<Employ> employList= q.list();
		return employList.toArray(new Employ[employList.size()]);
	}
	
	public String addEmploy(Employ employ) {
		sf=SessionHelper1.getConnection();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		s.save(employ);
		t.commit();
		return "EmployShowNew.xhtml?faces-redirect=true";
	}
	
	public String deleteEmploy(int id) {
		 sf =SessionHelper1.getConnection();
			Session s = sf.openSession();
			Employ employ= new Employ();
			Query q = s.createQuery("from Employ where id="+id);
			List<Employ> ulist = q.list();
			if (ulist.size() == 1) {
				 employ = ulist.get(0);
				Transaction t = s.beginTransaction();
			    s.delete(employ);
			    t.commit();
			    System.out.println("Record Deleted...");
			}
			return"EmployShowNew.xhtml";
			
		}
	
	public String searchEmploy(Employ employ) {
		
		sessionMap.put("e1", employ);  
		return "updateemploy.xhtml";
		
	}
	
	public String updateEmploy(Employ employ) {
		 sf =SessionHelper1.getConnection();
			Session s = sf.openSession();
			Transaction t=s.beginTransaction();
			s.update(employ);
			t.commit();
			return "MainTab.xhtml";
	}
	
	
}
