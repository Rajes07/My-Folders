package jsf.HibJsf.employ;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class SessionHelper1 {
	
	public static SessionFactory getConnection() {
		SessionFactory sf = new AnnotationConfiguration().configure("hibernate-1.cfg.xml").buildSessionFactory();
		return sf;
}
}