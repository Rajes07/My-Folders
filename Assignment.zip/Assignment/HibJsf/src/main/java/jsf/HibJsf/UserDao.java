package jsf.HibJsf;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

@ManagedBean(name="userdao")
public class UserDao {
	 private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();  
	SessionFactory sf;
	public Users[] showUser() {
		sf = SessionHelper.getConnection();
		Session s = sf.openSession();
		Query q = s.createQuery("from Users");
		List<Users> userList= q.list();
		return userList.toArray(new Users[userList.size()]);
	}
	
	
	public String addUser(Users user) {
	    sf = SessionHelper.getConnection();
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(user);
		t.commit();
		System.out.println( "Users Stored in Database...");
		return "InputShow.xhtml";
	}
	
	public String deleteUser(int id) {
	 sf =SessionHelper.getConnection();
		Session s = sf.openSession();
		Users user= new Users();
		Query q = s.createQuery("from Users where id="+id);
		List<Users> ulist = q.list();
		if (ulist.size() == 1) {
			 user = ulist.get(0);
			Transaction t = s.beginTransaction();
		    s.delete(user);
		    t.commit();
		    System.out.println("Record Deleted...");
		}
		return"userShow.xhtml";
		
	}
	
	public String searchUser(int id) {
		 sf =SessionHelper.getConnection();
		 Session s = sf.openSession();
		
		 Query q = s.createQuery("from Users where id="+id);
		 List<Users> ulist=q.list();
		 if(ulist.size()==1) {
		 	Users user= new Users();
		 	user.setId(id);
		 	
		 	
		 	
		 
		 	sessionMap.put("userV", user);  
		 
			return "searchd";
		 }
		return"edit.xhtml" ;	
	}
	
	public String search(Users user) {
		sessionMap.put("editUser", user);
		return "edit.xhtml";
	}
	
	public String updateUser(Users user) {
		sf = SessionHelper.getConnection();
		Session s = sf.openSession();
		Transaction t=s.beginTransaction();
		s.update(user);
		t.commit();
		return "MainTab.xhtml?faces-redirect=true";
	}
	


}
