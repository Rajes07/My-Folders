package jsf.HibJsf.employ;

public enum Gender {

	MALE, FEMALE
}
