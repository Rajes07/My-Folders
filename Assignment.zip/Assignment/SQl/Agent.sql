
select * from agent;

select * from agent where MaritalStatus= 0;

select AgentId, firstName,LastName,city,state, MaritalStatus,
case MaritalStatus
when 0 then 'unmarried'
when 1 then 'married' 
else 'invalid'
end 'status'
from agent;