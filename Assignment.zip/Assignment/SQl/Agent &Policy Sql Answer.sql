

Agent Ans:
-----------
1.Display all records from agent table
     select * from agent; 
----------------------------------------------------------
2.Display all records from Agent whose MaritalStatus is 0
     select * from agent where MaritalStatus= 0; 
--------------------------------------------
3.Display AgentId, firstName,LastName,city,state, MaritalStatus, 
	if maritalStatus is 0 then 'Unmarried'
        if maritalStatus is 1 then 'Married' 


select AgentId, firstName,LastName,city,state, MaritalStatus,
case MaritalStatus
when 0 then 'unmarried'
when 1 then 'married' 
else 'invalid'
end 'status'
from agent; 
--------------------------------------***************----------------------------
policy Ans:
----------
4) Display all records from Polic
    select * from policy;
------------------------------- 
5) Display all records whose Annualpremium > 100000
   select * from policy where Annualpremium > 100000; 
------------------------------ 
6) Display PolicyID, AppNumber, PayMode, 	
	if paymode is 1 then 'Yearly'
	if payMode is 2 then 'Half-Yearly'
	if payMode is 3 then 'Quarterly'


select PolicyID, AppNumber, PaymentModeID, 
case PaymentModeID
when 1 then 'yearly'
when 2 then 'haly-yearly'
when 3 then 'quarterly'
end 'year' from policy; 

----------------------------****************_________________________