select  from policy;


select  from policy where Annualpremium  100000;


select PolicyID, AppNumber, PaymentModeID, 
case PaymentModeID
when 1 then 'yearly'
when 2 then 'haly-yearly'
when 3 then 'quarterly'
end 'year' from policy;