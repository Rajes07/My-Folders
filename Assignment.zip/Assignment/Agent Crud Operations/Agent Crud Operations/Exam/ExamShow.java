package com.java.infinite.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ExamShow {
public static void main(String[] args) {
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	try {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam",
				"root","root"); 
		String cmd="select * from Agent1";
		PreparedStatement pst = con.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery(); 
		while(rs.next()) { 
			
			
			System.out.println("Agent No   " +rs.getInt("AgentId"));
			System.out.println("Agent Name  " +rs.getString("name"));
			System.out.println("Gender   " +rs.getString("gender"));
			System.out.println("City  " +rs.getString("city"));
			System.out.println("MaritalStatus  " +rs.getString("maritalstatus"));
			System.out.println("Premium   " +rs.getInt("premium"));
			System.out.println("--------------------------------------------");
			System.out.println("");
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
}
}
