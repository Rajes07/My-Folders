package com.java.infinite.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ExamUpdate { 
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in); 
		int AgentID,premium;
		String name,city,MaritalStatus;
		Gender gender = null;
		System.out.println("Enter AgentID");
		AgentID=sc.nextInt();
		System.out.println("Enter Agent First Name");
		name=sc.next();	 
		System.out.println("Enter CIty");
		city=sc.next();
		System.out.println("Enter premium");  
		premium=sc.nextInt();
		System.out.println("Enter Marital Status");
		MaritalStatus=sc.next();
		System.out.println("Enter gender");
		String gen=sc.next();
		if(gen.toUpperCase().equals("MALE")) {
			gender=Gender.MALE;
		}
		if(gen.toUpperCase().equals("FEMALE")) {
			gender=Gender.FEMALE;
		}
		String cmd="update Agent set name=?,gender=>,city=?,MaritalStatus=?,premium= where AgentID=?"; 
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam",
					"root","root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PreparedStatement pst;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(2,name);
			pst.setString(3, gender.toString());
			pst.setString(4, city);
			pst.setString(5, MaritalStatus);
			pst.setInt(1, AgentID);
			pst.setInt(6, premium);
			pst.executeUpdate();
			System.out.println("*** Record Updated ***");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
