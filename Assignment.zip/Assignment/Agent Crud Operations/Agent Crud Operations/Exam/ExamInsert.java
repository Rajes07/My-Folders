package com.java.infinite.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ExamInsert {


private static final String Firstname = null;

public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	int AgentID,MaritalStatus,premium;
	String name,city; 
	Gender gender = null ;   
	System.out.println("Enter AgentID");
	AgentID=sc.nextInt();
	System.out.println("Enter Agent NAME");
	name=sc.next();	 
	System.out.println("Enter CIty");
	city=sc.next();
	System.out.println("Enter premium"); 
	premium=sc.nextInt();
	System.out.println("Enter Marital Status");
	MaritalStatus=sc.nextInt(); 
	System.out.println("Enter gender");
	String gen=sc.next();
	if(gen.toUpperCase().equals("MALE")) {
		gender=Gender.MALE;
	}
	if(gen.toUpperCase().equals("FEMALE")) {
		gender=Gender.FEMALE;
	}
	String cmd="insert into Agent1(AgentID,name,city,gender,MaritalStatus,premium)values(?,?,?,?,?,?)"; 
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	try {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam",
				"root","root"); 
		PreparedStatement pst=con.prepareStatement(cmd); 
		pst.setInt(1, AgentID);
		pst.setString(2, name); 
		pst.setString(3,city);
		pst.setString(4,gender.toString());
		pst.setInt(5, MaritalStatus); 
		pst.setInt(6, premium);
		pst.executeUpdate();
		System.out.println("*********Record Added Sucessfully****");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
}
}
