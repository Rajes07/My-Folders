As the database name is Exam , i have created the class names as Exam.
and performed the crud operation as 
 (i)ExamShow
 (ii)ExamInsert 
(iii)ExamDelete 
... so and so 



-----------**Thank You**-------------