-- MODULE 6

-- 3) What is the result of x > ANY (10,20), if x is 15? ___1_____.


-- 4) Subquery always passes the result to the main-query [T/F] __TRUE___


-- 5) Subquery can be used in VALUES clause of INSERT command.[T/F] _TRUE___. 	


-- 6) Display details of courses taken by students who joined in the month of june, 2001.


-- 7) Delete the details of students who haven’t paid anything so far

-- 8) Display the details of course for which there are more than 3 batches.

-- 9) Display the details of course that has highest number of batches.

-- 10.	Change the ENDDATE of batch B8 to the ENDDATE of most recent batch.
-- 11) Display the details of students who haven’t paid total amount so far.



-- 12) Display the details of payment made by students of Oracle batch started on 5-dec-2000.
