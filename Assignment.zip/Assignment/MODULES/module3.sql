-- MODULE 3

-- 1) Display all matching records from batches and Courses table. 
	  SELECT *FROM BATCHES
	  INNER JOIN COURSES ON BATCHES.CCODE=COURSES.CCODE; 


-- 2) Display matching/unmatching records from batches and courses table.
	  SELECT * FROM BATCHES
	  LEFT JOIN COURSES ON BATCHES.CCODE=COURSES.CCODE;


-- 3) Display all matching records ascending order of stdate
	 SELECT * FROM BATCHES
	 INNER JOIN COURSES ON COURSES.CCODE=BATCHES.CCODE
	 ORDER BY STDATE ASC;


-- 4) Display all matching and unmatching records from batches, courses and faculty table. 
	 SELECT * FROM BATCHES
	 LEFT JOIN COURSES ON BATCHES.CCODE=COURSES.CCODE
	 LEFT JOIN FACULTY ON BATCHES.FACCODE=FACULTY.FACCODE;