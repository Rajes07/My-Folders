-- MODULE 4

-- 1) What is required to join two tables?
          Two Tables with matching columns and a JOIN condition

-- 2) What is meant by self-join?
          A table joined with itself is called Self Join.


-- 3) How do you qualify a column that is existing in two or more tables that are being joined?
         One table must contain a column that is a reference for the other table.It can be done by using 'Table_name.Column_name'.


--4) What is table alias? Is it stored anywhere?
         Alias is used to temporarily assign another name to a table or column for the duration of a SELECT query. They are stored in ~/. bashrc (bash) or ~/


--5)What happens when you join two tables without any condition?
        Joining two tables without any condition will lead to the cross product of the two tables. and The output of two cross joined tables without any condition will be n* m where n and m are number of records in two tables.


-- 6) Display rollno, student name, pay date and amount paid.


-- 7) Display rollno , student name, batch code ,  stdate of batch  and faculty code.


-- 8) Display rollno , student name, course name  ,  stdate  of batch  and faculty code.


-- 9) Display rollno , student name, course name , faculty code and enddate of all batches that were completed.


-- 10) Display students who have got more number of characters in name than the student with roll number 10.


-- 11) Display rollno, student name, email , pay date and amount paid.


-- 12) In previous query include the details of student who haven’t paid anything so far.

-- 13) Display the details of students who have paid nothing so far.
          