-- Display records from students (Batch-wise total no.of students exists) 
-- 2) Display total payment paid by all students from payment table student-wise
-- 3) Display total no.of records from Payment table
-- 4) Display total no.fo records from payment table, by eliminating duplicate student No
-- 5) Display the ccode, max(stdate) from batches table.
-- 6) Display max. fee from Course table. 
-- 7) Display max. fee from Course table w.r.t. Ccode 
-- 8) Display total courses from batches table which are started in last 3 months
-- 9) Display all courses from batches table w.r.t. Ccode (min 2 entries required)
-- 10) Display all records from batches table, which courses are started last 3 months 
-- 11) Display information from course_faculty table, as which faculty taking how many courses in ascending order w.r.t. Count 

use institute;

select * from students where BCODE in(select BCODE from students group by BCODE); 

select count(rollno),sum(amount) from PAYMENTS;

select count(*) from payments; 
 
select count(distinct(rollno)) from payments; 

select max(fee) from courses;

select max(fee),CCODE from courses;

select count(CCODE), STDATE from batches where STDATE>now() -interval 3 month;

select BCODE ,CCODE from batches; 

select FCODE,CCODE from COURSE_FACULTY group by FCODE having count(CCODE) order by CCODE asc; 



