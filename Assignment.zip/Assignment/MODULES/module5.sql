-- MODULE 5
             
-- 1) Get the details of students who have paid today.


-- 2) Display the details of batches handled by faculty name ‘Kevin Loney’.

-- 3) display the details of the faculty members who have not taken any batch in the last three months.

-- 4) displays the details of batches that are taken by faculty with qualification MS or the course fee is more than 5000.

-- 5) displays the details of the students who belong to batches that are taken by faculty with qualification MS.

-- 6) displays the details of the batches that have taken maximum duration among the batches of the same course.

-- 7) Get the details of course that has highest course fee.
-- 8) Get the details of students who have made a payment in the last month but no in the current month.
