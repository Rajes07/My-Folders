package com.java.infinite.LmsLeave;

public enum LeaveStatus {
     PENDING, APPROVED,DENIED
}
