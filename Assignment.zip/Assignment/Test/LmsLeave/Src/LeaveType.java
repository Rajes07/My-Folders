package com.java.infinite.LmsLeave;

public enum LeaveType {
    El
}
