package com.java.infinite.SpringJdbcAgent.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.infinite.SpringJdbcAgent.dao.AgentDAO;
import com.java.infinite.SpringJdbcAgent.model.Agent;





@Controller
public class HomeController {
	
	 @Autowired
	 private AgentDAO agentDAO;
	 
	 
	 @RequestMapping(value = "/deleteagent", method = RequestMethod.GET)
	 public ModelAndView deleteagent(HttpServletRequest request) {
	     int agentId = Integer.parseInt(request.getParameter("agentId"));
	    agentDAO.deleteAgent(agentId);
	     return new ModelAndView("redirect:/");
	 } 
	 
	 @RequestMapping(value = "/updateAgent", method = RequestMethod.POST)
	 public ModelAndView updateemploy(@ModelAttribute Agent agent) {
		 agentDAO.updateAgent(agent);
	     return new ModelAndView("redirect:/");
	 }
	
	 @RequestMapping(value="/editAgent")
		public ModelAndView editEmploy(HttpServletRequest request) {
		    int agentId = Integer.parseInt(request.getParameter("agentId"));
		      Agent agent=agentDAO.get(agentId);
		    ModelAndView model = new ModelAndView("agentSearchForm");
		    model.addObject("agent", agent);
		    
		    return model;
		}
	 @RequestMapping(value = "/saveagent", method = RequestMethod.POST)
	 public ModelAndView saveagent(@ModelAttribute Agent agent) {
	     agentDAO.addAgent(agent);
	     return new ModelAndView("redirect:/");
	 }

	 @RequestMapping(value = "/newagent", method = RequestMethod.GET)
	 public ModelAndView addemploy(ModelAndView model) {
	     Agent agent = new Agent();
	     model.addObject("agent", agent);
	     model.setViewName("agentform");
	     return model;
	 }
	 
	 @RequestMapping(value="/")
		public ModelAndView listAgent(ModelAndView model) throws IOException{
		     List<Agent> listAgent = agentDAO.list();
		     model.addObject("listAgent", listAgent);
		     model.setViewName("home");
		     return model;
		 }
	
	
}
