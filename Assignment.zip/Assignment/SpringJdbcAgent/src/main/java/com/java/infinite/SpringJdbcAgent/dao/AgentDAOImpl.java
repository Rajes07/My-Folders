package com.java.infinite.SpringJdbcAgent.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.java.infinite.SpringJdbcAgent.model.Agent;



public class AgentDAOImpl implements AgentDAO {
	
private JdbcTemplate jdbcTemplate;
	
	public AgentDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<Agent> list() {
		 String sql = "SELECT * FROM Agent";
		    List<Agent> listContact = jdbcTemplate.query(sql, new RowMapper<Agent>() {
		        @Override
		        public Agent mapRow(ResultSet rs, int rowNum) throws SQLException {
		           Agent agent = new Agent();
		 
		            agent.setAgentId(rs.getInt("AgentId"));
		            agent.setName(rs.getString("Name"));
		            agent.setCity(rs.getString("City"));
		            agent.setGender(rs.getString("GENDER"));
		            agent.setMaritalStatus(rs.getInt("MaritalStatus"));
		            agent.setPremium(rs.getDouble("Premium"));
		         
		            return agent;
		        }
		 
		    });
		 
		    return listContact;
	}

	@Override
	public void addAgent(Agent agent) {
		String cmd = "insert into Agent(AgentID,Name,city,GENDER,MaritalStatus,"
				+ "Premium) values(?,?,?,?,?,?)";
		 jdbcTemplate.update(cmd, agent.getAgentId(),agent.getName(),agent.getCity(),
				 agent.getGender().toString(), 
				 agent.getMaritalStatus(),agent.getPremium());	
		
	}

	@Override
	public void updateAgent(Agent agent) {
	
	    	String cmd="Update Agent set Name=?, gender=?,city=?,MaritalStatus=?,premium=? where AgentId=?";
	       jdbcTemplate.update(cmd,agent.getName(),agent.getGender().toString()
	    			,agent.getCity(),agent.getMaritalStatus(),agent.getPremium(),agent.getAgentId());
	    	
	}
	@Override
	public Agent get(int agentId) {
		String sql = "select * from Agent where AgentID=?";
		  return jdbcTemplate.query(sql,new Object[] {agentId}, new ResultSetExtractor<Agent>() {
		        @Override
		        public Agent extractData(ResultSet rs) throws SQLException,
		                DataAccessException {
		            if (rs.next()) {
		                Agent a = new Agent();
		                a.setAgentId(rs.getInt("AgentId"));
			            a.setName(rs.getString("Name"));
			            a.setCity(rs.getString("City"));
			            a.setGender(rs.getString("Gender"));
			            a.setMaritalStatus(rs.getInt("MaritalStatus"));
			            a.setPremium(rs.getDouble("Premium"));
			            return a;
		            }
		 
		      
		        	return null;
		        }
		 
		    });
	}

	@Override
	public void deleteAgent(int agentId) {
		String sql = "DELETE FROM Agent WHERE AgentID=?";
	    jdbcTemplate.update(sql, agentId);
		
	}

	
}
