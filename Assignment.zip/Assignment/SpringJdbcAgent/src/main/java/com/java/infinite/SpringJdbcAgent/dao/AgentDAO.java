package com.java.infinite.SpringJdbcAgent.dao;

import java.util.List;

import com.java.infinite.SpringJdbcAgent.model.Agent;


public interface AgentDAO {
	
	 List<Agent> list();
	void addAgent(Agent agent);
	void updateAgent(Agent agent);
	Agent get(int agentId);
	void deleteAgent(int agentId);

}
