package com.java.infinite.SpringJdbcAgent.model;

public enum Gender {
	
	MALE,FEMALE

}
