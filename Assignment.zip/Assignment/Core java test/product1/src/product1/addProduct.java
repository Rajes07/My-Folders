package product1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class addProduct {

	public static void main(String[] args) {
		List<Product> list = new ArrayList<Product>();
		list.add(new Product(1, "TV", 20000));
		list.add(new Product(2, "mobile", 10000));
		list.add(new Product(3, "fridge", 40000));
		list.add(new Product(4, "Mixer", 2500));
		list.add(new Product(5, "oven", 8000));
		list.add(new Product(6, "telephone", 1800));
		list.add(new Product(7, "chair", 1000));
		list.add(new Product(8, "Washing Machine", 15000));
		list.add(new Product(9, "Stove", 4000));
		list.add(new Product(10, "Fan", 2500));

		list.forEach((Product) -> System.out.println(Product));

		Collections.sort(list, new sortProduct());
		listToStream(list.stream());
		System.out.println("AfterSorting........");
		System.out.println(list);

	}

	private static Stream<String> listToStream(Stream<Product> product) {

		List<Product> list1 = product.filter(p -> p.getPrice() < 3000).collect(Collectors.toList());
		System.out.println("after sorting price below 3000");
		list1.forEach(System.out::println);
		return null;
	}
}
