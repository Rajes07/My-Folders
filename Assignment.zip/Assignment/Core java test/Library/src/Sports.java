
public class Sports extends Book {

	@Override
	public void bookName() {
		// TODO Auto-generated method stub
		System.out.println("its book");
	}

	@Override
	public void Author() {
		// TODO Auto-generated method stub
		System.out.println("its author");
	}

}
