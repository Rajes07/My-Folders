
public interface Gk {
	void bookName();
	void author();
}
