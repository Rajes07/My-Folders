
public abstract class Book {
    public abstract void bookName();
    public abstract void Author();
 }
