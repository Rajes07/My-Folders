
public class Academics extends Book {

	@Override
	public void bookName() {
		// TODO Auto-generated method stub
		System.out.println("its academics book");
		
	}

	@Override
	public void Author() {
		// TODO Auto-generated method stub
		System.out.println("its author name");
	}

}
