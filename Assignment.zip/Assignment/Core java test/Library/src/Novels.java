
public class Novels extends Book {

	@Override
	public void bookName() {
	   System.out.println("Its novel");
	}

	@Override
	public void Author() {
		System.out.println("Its author name");		
	}

}
