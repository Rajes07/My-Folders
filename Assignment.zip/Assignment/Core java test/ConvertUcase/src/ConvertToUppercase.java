import java.util.Scanner;

public class ConvertToUppercase {



	
	public static void main(String[] args) {
	  
		 String input;
		 
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter a string :");
		 input = sc.next();
		 
		 System.out.println("lower case string is :"  +input);
		 
		 char strArr[] = input.toCharArray();
		 for(int x=0 ; x < strArr.length ; x++) {
			 
			 if(strArr[x]>= 'a' && strArr[x] <= 'z') {
				 strArr[x] = (char) ((int) strArr[x] -32);
			 }
			 
		 }
		 
		 System.out.println("upper case is :");
		 
		 for(int x=0 ; x< strArr.length; x++) {
			 System.out.println(strArr[x]);
		 }
		
	}

}