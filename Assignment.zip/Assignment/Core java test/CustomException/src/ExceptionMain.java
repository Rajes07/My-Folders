import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExceptionMain {
	public static void main(String[] args) throws CustomException {
		String str;
	   System.out.println("Enter the string");
	   Scanner sc= new Scanner(System.in);
	   str=sc.next();
	   Pattern p = Pattern.compile(
	            "[^a-z0-9 ]", Pattern.CASE_INSENSITIVE); 
	   Matcher m = p.matcher(str);
	   boolean res = m.find();
	   if (res) {
        
            throw new CustomException("String contains Special Characters");
           }
       else {
           System.out.println(
               "No Special Characters found in String 1");
	}

}
}
