package com.java.spring.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.spring.customRepo.WalletDao;
import com.java.spring.model.Wallet;
import com.java.spring.repo.WalletRepo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class WalletService {

	@Autowired
    private WalletRepo repo;
	
	@Autowired
	private WalletDao dao;
	
	public Wallet search(int walId) {
		return repo.findById(walId).get();
	}
	
	public List<Wallet> showCustomerWallets(int custId) {
		return dao.showCustomerWallets(custId);
	}
}
