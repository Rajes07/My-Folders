package com.java.spring.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.java.spring.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer>{

}
