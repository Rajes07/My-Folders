package com.java.spring.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.java.spring.model.Wallet;

public interface WalletRepo extends JpaRepository<Wallet, Integer> {

	

}
