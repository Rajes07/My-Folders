public class CurrentBill {

	
	public static void main(String[] args){
		System.out.println("hello");
	}
}public class CurrentBill {
	
	
	public void calc(float units){
		
		double bill=0.00;
		
		if(units<100){
			
			bill=units*1.20;
			
		}else if(units<300){
			
			bill=100*1.20+((units-100)*2);
			
		}else{
			
			bill=(100*1.20)+(200*2)+((units-300)*3);
		}
		
		
		System.out.println("the bill is  " +bill);
		
	}
	
	
	
	
	
	public static void main(String[] args){
		
		float units=150;
		CurrentBill obj= new CurrentBill();
			obj.calc(150);
			obj.calc(200);
			obj.calc(250);
			obj.calc(350);
		}
	
		
	
	