package com.java.infinite.BankJdbc;

import java.sql.SQLException;
import java.util.Scanner;

public class SearchAccountMain { 
	public static void main(String[] args) {
		int AccountNo;
		System.out.println("enter accno");
		Scanner sc= new Scanner(System.in);
		AccountNo = sc.nextInt();
		BankDAO dao= new BankDAO();
		try {
			Bank bank=dao.searchAccNo(AccountNo);
			if(bank!=null) {
				System.out.println(bank);
			}else {
				System.out.println("Record not found");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
