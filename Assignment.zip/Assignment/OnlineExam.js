var Questions = new Array(
    "1. The father of C,C++ & Unix is",
    "2. The Open source among following is ",
    "3. Pancake Sorting Algorithm and BASIC Interpreter was written by",
    "4. Larry page and Sergei Brinn are Co-Founders of",
    "5. The first computer to defeat Chess Grandmaster was",
    "6.The first generation computers used ……………. languages. ",
    "7.What application allows you to gain access to the internet",
    "8.What is the keyboard shortcut for copy and paste?",
    "9.These are specially designed computers that perform complex calculations extremely rapidly",
    "10 The CPU and memory are located on the ",
    "11.It is a set of computer programs used on a computer to help perform tasks",
    "12.which is keyboard shrtcut to copy all the things",
    "13.Which is keyboard shortcut for cut  ",
    "14.which is  keyboard shortcut to save the files",
    "15.which is the keyboard shortcut to come back to previous tab"
);
NoOfQuestions = Questions.length;
QuestionNo = 0;
selectedAnswer=15;
marks=0
Choosed = false;
Answers = new Array(NoOfQuestions);
CorrectAnswers = new Array(NoOfQuestions);
for (var i = 0 ; i < NoOfQuestions ; i++)
	{
	    Answers[i] = new Array(14);
	}

    // [0][0] [0][1] [0][2] [0][3]
    // [1][0] [1][1] [1][2] [1][3]...

Answers[0][0] = "Forouzan";
Answers[0][1] = "Dennis Ritchie";
Answers[0][2] = "Andrew Tenenbaum";
Answers[0][3] = "Dijkstra";
CorrectAnswers[0] = 2;


Answers[1][0] = "Windows XP";
Answers[1][1] = "Mac OS X";
Answers[1][2] = "Linux Ubuntu";
Answers[1][3] = "Sun Solaris";
CorrectAnswers[1] = 4;

Answers[2][0] = "Steve Jobs";
Answers[2][1] = "Steve William";
Answers[2][2] = "Bill Gates";
Answers[2][3] = "Jerry yang";
CorrectAnswers[2] = 3;


Answers[3][0] = "Yahoo";
Answers[3][1] = "Rediff";
Answers[3][2] = "Google";
Answers[3][3] = "Apple";
CorrectAnswers[3] = 3;

Answers[4][0] = "Chess Zeus";
Answers[4][1] = "Armageddon";
Answers[4][2] = "White Knight";
Answers[4][3] = "Deep Blue";
CorrectAnswers[4] = 4; 

Answers[5][0]="Machine language";
Answers[5][1]="code language";
Answers[5][2]="Assemble language";
Answers[5][3]="all the above";
CorrectAnswers[5]=1; 


Answers[6][0]="chrome";
Answers[6][1]="safari";
Answers[6][2]="edge";
Answers[6][3]="all the above";
CorrectAnswers[6]=4;


Answers[7][0]="ctrl+v";
Answers[7][1]="ctrl+c";
Answers[7][2]="ctrl+x";
Answers[7][3]="1 and 2";
CorrectAnswers[7]=4;


Answers[8][0]="server";
Answers[8][1]="laptop";
Answers[8][2]="super computer";
Answers[8][3]="main frame";
CorrectAnswers[8]=3;


Answers[9][0]="motherboard";
Answers[9][1]="output devices";
Answers[9][2]="storage";
Answers[9][3]="none";
CorrectAnswers[9]=1;


Answers[10][0]="software";
Answers[10][1]="memory";
Answers[10][2]="processor";
Answers[10][3]="all";
CorrectAnswers[10]=1;


Answers[11][0]="ctrl+c";
Answers[11][1]="ctrl+a";
Answers[11][2]="ctrl+m";
Answers[11][3]="a and b";
CorrectAnswers[11]=2; 


Answers[12][0]="ctrl+l";
Answers[12][1]="ctrl+d";
Answers[12][2]="ctrl+x";
Answers[12][3]="none";
CorrectAnswers[12]=3;


Answers[13][0]="ctrl+s";
Answers[13][1]="ctrl+shift+s";
Answers[13][2]="ctrl+m";
Answers[13][3]="1 and 2";
CorrectAnswers[13]=4;


Answers[14][0]="alt+<";
Answers[14][1]="alt+>";
Answers[14][2]="alt+tab";
Answers[14][3]="none";
CorrectAnswers[14]=2;
function AnswerChoosed(ans) {
    selectedAnswer = ans;   
    Choosed=true; 
}

function nextQuestion() {
    if (Choosed) {
        if (selectedAnswer == CorrectAnswers[QuestionNo]) {
            marks++;
        }
    if (QuestionNo < NoOfQuestions-1) {
        QuestionNo++;
        loadQuestion();
        Choosed=false;
    } else {
        alert("End of Examination \n"+"Marks Are : "+marks+"");
    }
  } else {
      alert("Please Select any option...");
  }
}

function loadQuestion() {
    document.getElementById("Question").innerHTML=Questions[QuestionNo];
    document.getElementById("Option0").innerHTML = "(a) " + Answers[QuestionNo][0];
	document.getElementById("Option1").innerHTML = "(b) " + Answers[QuestionNo][1];
	document.getElementById("Option2").innerHTML = "(c) " + Answers[QuestionNo][2];
	document.getElementById("Option3").innerHTML = "(d) " + Answers[QuestionNo][3];
    document.getElementById("Opt1").checked = false;	
	document.getElementById("Opt2").checked = false;	
	document.getElementById("Opt3").checked = false;	
	document.getElementById("Opt4").checked = false;
}
