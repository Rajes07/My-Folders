package com.java.infinite.leave;

public class App {

  public static void main(String[] args) {
    System.out.println("Hello World!");
  }

}
