package com.java.spring.customRepo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.java.spring.model.Menu;

@Repository
public class MenuDao {

	@Autowired  
    JdbcTemplate jdbc;  
	
	public Menu searchMenu(int menuId) {
		String cmd = "select * from Menu where MENU_ID=?";
		List<Menu> menuList=jdbc.query(cmd,new Object[] {menuId}, new RowMapper<Menu>() {

			@Override
			public Menu mapRow(ResultSet rs, int arg1) throws SQLException {
				Menu menu = new Menu();
				menu.setMenuId(rs.getInt("MENU_ID"));
				menu.setMenuItem(rs.getString("MENU_ITEM"));
				menu.setMenuPrice(rs.getDouble("MENU_PRICE"));
				menu.setMenuCalories(rs.getInt("MENU_CALORIES"));
				menu.setMenuStatus(rs.getString("MENU_STATUS"));
				menu.setMenuType(rs.getString("MENU_TYPE"));
				menu.setMenuRating(rs.getString("MENU_RATING"));
				return menu;
			}


			
		});
		return menuList.get(0);
	}
}
