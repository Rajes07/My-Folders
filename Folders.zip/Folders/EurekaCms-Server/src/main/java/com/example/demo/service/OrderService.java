package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.CustomRepo.MenuDao;
import com.example.demo.CustomRepo.OrderDao;
import com.example.demo.CustomRepo.WalletDao;
import com.example.demo.model.Menu;
import com.example.demo.model.Orders;
import com.example.demo.model.Wallet;
import com.example.demo.repo.OrdersRepo;



@Service
@Transactional
public class OrderService {

	@Autowired
    private OrdersRepo repo;
	
	@Autowired
	private OrderDao dao;
	
	@Autowired 
	private MenuDao mdao;
	
	@Autowired 
	private WalletDao wdao;
	
	@Autowired
	private OrderDao odao;
	
	public String acceptOrRejectOrder(int ordId,int venId,String status) {
		Orders orders = odao.searchByOrderId(ordId);
		int vid = orders.getVenId();
		int cid = orders.getCusId();
		String walSource = orders.getWalSource();
		double billAmount = orders.getOrdBillamount();
		if (vid!=venId) {
			return "You are unauthorized vendor...";
		} 
		if (status.toUpperCase().equals("YES")) {
			return odao.updateStatus(ordId,"ACCEPTED");
		} else {
			odao.updateStatus(ordId, "DENIED");
			wdao.refundWallet(cid, walSource, billAmount);
			return "Order Rejected and Amount Refunded...";
			
		}
	}
	
	public String placeOrder(Orders order) {
		Menu menu = mdao.searchMenu(order.getMenuId());
		Wallet wallet = wdao.showCustomerWallet(order.getCusId(), order.getWalSource());
		double balance = wallet.getWalAmount();
		double billAmount = order.getOrdQty()*menu.getMenuPrice();
		System.out.println(balance);
		System.out.println(billAmount);
		if (balance-billAmount > 0) {
			order.setOrdStatus("PENDING");
			order.setOrdBillamount(order.getOrdQty()*menu.getMenuPrice());
			repo.save(order);
			wdao.updateWallet(order.getCusId(), order.getWalSource(), billAmount);
			return "Order Placed Successfully...and Amount Debited";
		}
		return "Insufficient Funds...";
	}
	public List<Orders> showVendorPendingOrders(int venId) {
		return dao.showVendorPendingOrders(venId);
	}
	public List<Orders> showVendorOrders(int venId) {
		return dao.showVendorOrders(venId);
	}
	public List<Orders> showCustomerOrders(int custId) {
		return dao.showCustomerOrders(custId);
	}
	public List<Orders> showCustomerPendingOrders(int custId) {
		return dao.showCustomerPendingOrders(custId);
	}
	public Orders search(int orderId) {
		return repo.findById(orderId).get();
	}
	public List<Orders> showOrders() {
		return repo.findAll();
	}
}
