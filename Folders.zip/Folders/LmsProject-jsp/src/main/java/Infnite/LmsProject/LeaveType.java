package Infnite.LmsProject;

public enum LeaveType {
     EL
}
